package com.jbnu.comall.model;

import java.util.List;

public class Examine {


    public String getExamine_text() {
        return examine_text;
    }

    public void setExamine_text(String examine_text) {
        this.examine_text = examine_text;
    }

    public String getExamine_info() {
        return examine_info;
    }

    public void setExamine_info(String examine_info) {
        this.examine_info = examine_info;
    }

    private String examine_info;
    private String examine_text;




}


