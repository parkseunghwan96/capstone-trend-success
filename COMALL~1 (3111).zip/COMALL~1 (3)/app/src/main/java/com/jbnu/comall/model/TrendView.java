package com.jbnu.comall.model;

import java.util.List;

public class TrendView {

    public String getTrend_image() {
        return trend_image;
    }

    public void setTrend_image(String trend_image) {
        this.trend_image = trend_image;
    }

    private String trend_image;

    private String trend_photo;

    public String getTrend_photo() {
        return trend_photo;
    }

    public void setTrend_photo(String trend_photo) {
        this.trend_photo = trend_photo;
    }
}

